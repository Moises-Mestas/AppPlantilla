package com.example.ventas.data;

public class xd {
}
